
const APPS_SCRIPT_ENDPOINT = "https://script.google.com/macros/s/AKfycbxlvgEYSzLz4viRYAKXGi0hAbd1eGE7ccvRw46532Sw_GUpUClA51IWgUmjTFCplmr1/exec";

export interface LogPayload {
  userId: string;
  timestamp: string;
  page: string;
  clickType: string; // 'UI_CLICK' | 'GLOBAL_CLICK' | 'CHAT' | 'CUSTOM_EVENT'
  coordinates: {
    x: number; y: number; pageX: number; pageY: number; nx: number; ny: number;
  };
  target: {
    tagName: string; id: string; className: string;
  };
  screenSize: {
    viewportWidth: number; viewportHeight: number; screenWidth: number; screenHeight: number;
  };
}

let currentUser: string = 'anonymous';
let currentPage: string = 'portal';

export const setUser = (name: string) => {
  currentUser = name || 'anonymous';
};

export const setPage = (page: string) => {
  currentPage = page || 'portal';
};

const getScreenSize = () => ({
    viewportWidth: window.innerWidth,
    viewportHeight: window.innerHeight,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height
});

// Centralized sender
export const sendLog = async (payload: LogPayload) => {
  try {
    // If payload is missing user/page, fill from state
    if (!payload.userId) payload.userId = currentUser;
    if (!payload.page) payload.page = currentPage;

    await fetch(APPS_SCRIPT_ENDPOINT, {
      method: 'POST',
      mode: 'no-cors', // 'no-cors' is required for Google Apps Script to accept the request without opaque response blocking
      headers: {
        'Content-Type': 'text/plain', // MUST be text/plain to avoid preflight OPTIONS request (which fails with 401)
      },
      body: JSON.stringify(payload),
    });
  } catch (error) {
    // Silently fail to avoid spamming console with network errors if blocked by extensions
  }
};

// Helper for Chat Logging
export const logChat = (sender: 'bot' | 'user', message: string) => {
    const payload: LogPayload = {
        userId: currentUser,
        timestamp: new Date().toISOString(),
        page: currentPage,
        clickType: 'CHAT',
        coordinates: { x: 0, y: 0, pageX: 0, pageY: 0, nx: 0, ny: 0 },
        target: {
            tagName: sender.toUpperCase(), // 'BOT' or 'USER'
            id: 'chat_message',
            className: message.substring(0, 1000) // Truncate if too long, store text in className
        },
        screenSize: getScreenSize()
    };
    sendLog(payload);
};

// Generic event logger adapted to new schema
export const logEvent = (
  eventType: string,
  component: string,
  details: any = {}
) => {
  // Map arbitrary events to the schema
  const payload: LogPayload = {
    userId: currentUser,
    timestamp: new Date().toISOString(),
    page: currentPage,
    clickType: 'CUSTOM_EVENT',
    coordinates: { x: 0, y: 0, pageX: 0, pageY: 0, nx: 0, ny: 0 },
    target: {
      tagName: component, // Use tagName for Component Name
      id: eventType,      // Use id for Event Name
      className: JSON.stringify(details).substring(0, 1000) // Use className for details
    },
    screenSize: getScreenSize()
  };
  sendLog(payload);
};
